﻿<template>
  <div class="p-6">
    <h1 class="text-2xl font-bold mb-4">Assistants -  Page</h1>
    <p class="text-gray-600">This is the Show.vue page for Assistants.</p>
  </div>
</template>

<script setup>
// Example placeholder component
</script>

<style scoped>
</style>
